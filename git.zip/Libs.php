<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Libs
 *
 * @author ismil
 */
class Libs {
    //put your code here
}

?>
