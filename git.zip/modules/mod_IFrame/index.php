<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


function mod_iframe($por){
    
    
    
    
    
    return "<iframe width='".$por['width']."' height='".$por['height']."' src='".$por['url']."'></iframe>";
}
?>
