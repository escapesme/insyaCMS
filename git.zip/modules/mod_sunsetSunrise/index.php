<?php
/*
 * Project :Scape
 * Version 2.0.1 2012
 * Copyright E-Scapes IT Solutions
 * Authors: IMI, AD, AMV
 * 
 */

function mod_sunsetSunrise($pro) {
    return getsun($pro['Longitude'], $pro['Latitude'], $pro['ptime']);
}
?>


<style>



</style>
