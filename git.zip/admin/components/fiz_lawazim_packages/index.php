<?php

/*
 * Project :Scape
 * Version 2.0.1 2012
 * Copyright E-Scapes IT Solutions
 * Authors: IMI, AD, AMV
 * 
 */




/* @var $lib  \libs\libs */
global $lib;

echo $lib->adminEng->getComponentMain();
?>



