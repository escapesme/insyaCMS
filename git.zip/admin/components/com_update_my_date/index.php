<?php

/*
 * Project :Scape
 * Version 2.0.1 2012
 * Copyright E-Scapes IT Solutions
 * Authors: IMI, AD, AMV
 * 
 */

global $lib;
$_GET['id'] = "3";
echo $lib->adminEng->getComponentMain("com_users", "admin", "edit");
?>


