/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


$(function(){
    
    /*
    $("#fileds_names_add_rcf").click(function(){
        
        
        
         
            
        
        
        
        
        requstcartFields
        
     
        var fileds_types_com =$("#fileds_types_rcf").val();
        var fileds_values_com =$("#fileds_values_rcf").val();
        var fileds_names_com =$("#fileds_names_rcf").val();
    
    
        $("#fileds_types").val($("#fileds_types_rcf").val()+";"+ fileds_types_com);
        $("#fileds_values").val($("#fileds_values_rcf").val()+";" +fileds_values_com);
        $("#fileds_names").val($("#fileds_names_rcf").val()+";"+ fileds_names_com);
        
        $("#fileds_types_com").val("");
        $("#fileds_values_com").val("");
        $("#fileds_names_com").val("");
        
        
        
    })*/
})