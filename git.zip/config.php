<?php

$setting["db_name"] = 'escapesm_gitfaiz';
$setting["db_user"] = 'escapesm_newfaiz';
$setting["db_pass"] = 'newfaiz5152';
$setting["db_host"] = 'localhost';



$setting["siteTitle"] = 'E-Scapes Main Repository';
$setting["admin_mail"] = 'info@e-scapes.me';

$setting["mailTitle"] = 'E-Scapes';
$setting["site_path"] = 'http://new.faizehaakimi.com/';

$setting["succeedClass"] = "succee";







$message['updateData'] = 'update Data ';
$message['updateDataFailed'] = 'update Data Failed';
$message['succeedClass'] = "succ";
$message['failedClass'] = "fail";
$message['warningClass'] = "warn";






$options['viewErorre'] = 1;
$options['viewErorreadmin'] = 1;

$options['emailType'] = "mandrill";

$options['emailkey'] = "nGUj100qBKp44CC7m4CHWQ";


$sms['userName'] = "";
$sms['password'] = "";
$sms['lang'] = "A";
$sms['MSMUrl'] = "http://217.52.114.3//kannelSending/Service.asmx?WSDL";
?>